import { site } from "@/site.config";

export default function Contact(){
  return (
    <div className="py-10 grid md:grid-cols-2 gap-8">
      <div>
        <h2 className="text-2xl font-bold text-navybrand">Contact & Location</h2>
        <p className="mt-2">{site.address}, {site.city}, {site.country}</p>
        <p className="mt-1">Phone: {site.phone} | WhatsApp: {site.whatsapp}</p>
        <p className="mt-1">Email: {site.email}</p>
        <p className="mt-1">Hours: {site.hours}</p>
        <p className="mt-2 text-sm text-gray-700">Service radius: {site.serviceRadiusKm} km</p>
        <div className="mt-4 card p-4">
          <div className="text-sm text-gray-700">Map</div>
          <iframe
            className="w-full h-64 rounded-2xl"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3683.727!2d88.3639!3d22.5676!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2sKolkata!5e0!3m2!1sen!2sin!4v0000000"
            loading="lazy" referrerPolicy="no-referrer-when-downgrade"></iframe>
        </div>
        <div className="mt-4 text-xs text-gray-500">For emergencies, call local services immediately.</div>
      </div>
      <form className="card p-6 space-y-3">
        <div className="font-semibold">Send us a message</div>
        <input placeholder="Your Name" />
        <input placeholder="Email" type="email" />
        <textarea placeholder="Message" rows={5}></textarea>
        <button className="btn btn-primary">Submit</button>
      </form>
    </div>
  );
}
