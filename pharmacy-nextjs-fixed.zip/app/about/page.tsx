import { site } from "@/site.config";

export default function About(){
  return (
    <div className="py-10 max-w-3xl">
      <h2 className="text-2xl font-bold text-navybrand">About Us</h2>
      <p className="mt-3 text-gray-700">
        {site.brand} has served the {site.city} community for over {site.pharmacist.years} years with a mission to deliver quick, reliable, and compassionate care.
      </p>
      <div className="card p-6 mt-6">
        <div className="font-semibold">Pharmacist-in-Charge</div>
        <p className="mt-2">{site.pharmacist.name}</p>
        <p>License No.: {site.pharmacist.licenseNo}</p>
        <p className="mt-2 text-sm text-gray-700">We believe in clear guidance, safe dispensing, and genuine medicines.</p>
      </div>
    </div>
  );
}
