export default function Blog(){
  return (
    <div className="py-10">
      <h2 className="text-2xl font-bold text-navybrand">Health Tips & Blog</h2>
      <div className="grid md:grid-cols-2 gap-6 mt-4">
        <article className="card p-6">
          <div className="font-semibold">How to store medicines safely at home</div>
          <p className="mt-2 text-sm text-gray-700">Cool, dry, and away from children. Check expiry dates regularly.</p>
          <a href="#" className="text-sm mt-3 inline-block">Read more</a>
        </article>
        <article className="card p-6">
          <div className="font-semibold">Seasonal allergies: quick relief tips</div>
          <p className="mt-2 text-sm text-gray-700">OTC antihistamines, saline sprays, and avoiding triggers can help.</p>
          <a href="#" className="text-sm mt-3 inline-block">Read more</a>
        </article>
      </div>
    </div>
  );
}
