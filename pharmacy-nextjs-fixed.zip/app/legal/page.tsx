export default function Legal(){
  return (
    <div className="py-10 space-y-8">
      <section className="card p-6">
        <h3 className="text-lg font-semibold">Privacy Policy</h3>
        <p className="mt-2 text-sm text-gray-700">We respect your privacy and handle data according to applicable laws.</p>
      </section>
      <section className="card p-6">
        <h3 className="text-lg font-semibold">Terms & Conditions</h3>
        <p className="mt-2 text-sm text-gray-700">Use of this site implies acceptance of our terms.</p>
      </section>
      <section className="card p-6">
        <h3 className="text-lg font-semibold">Return & Refund Policy (Non‑Rx)</h3>
        <p className="mt-2 text-sm text-gray-700">Eligible items can be returned within 7 days if unopened.</p>
      </section>
      <section className="card p-6">
        <h3 className="text-lg font-semibold">Disclaimer</h3>
        <p className="mt-2 text-sm text-gray-700">This content is for information and does not replace professional medical advice.</p>
      </section>
      <section className="text-xs text-gray-600">
        Prescription-only medicines are dispensed only against a valid prescription from a registered medical practitioner.
      </section>
    </div>
  );
}
