'use client';
import { useState } from "react";
import { site } from "@/site.config";

export default function UploadPage(){
  const [file, setFile] = useState<File|null>(null);
  const [consent, setConsent] = useState(false);
  const [status, setStatus] = useState<string>('');

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if(!file || !consent){
      setStatus("Please attach a file and check consent.");
      return;
    }
    setStatus("Uploaded! Our pharmacist will review and contact you for confirmation → payment → delivery.");
  };

  return (
    <div className="py-10 max-w-2xl">
      <h2 className="text-2xl font-bold text-navybrand">Upload Prescription</h2>
      <p className="mt-2 text-gray-700">Accepted formats: PDF/JPG/PNG. You can also use your camera.</p>
      <form onSubmit={onSubmit} className="card p-6 mt-4 space-y-4">
        <input type="file" accept="application/pdf,image/*" capture="environment" onChange={e=>setFile(e.target.files?.[0]||null)} />
        <input type="text" placeholder="Your WhatsApp number" defaultValue={site.whatsapp} />
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" checked={consent} onChange={e=>setConsent(e.target.checked)} />
          I consent to be contacted on WhatsApp for this order.
        </label>
        <button className="btn btn-primary" type="submit">Submit</button>
        {status && <div className="text-sm">{status}</div>}
        <div className="text-xs text-gray-600">
          Schedule H/Prescription-only medicines are dispensed against a valid prescription.
        </div>
      </form>
    </div>
  );
}
