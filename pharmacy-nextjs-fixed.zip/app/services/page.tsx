export default function Services(){
  return (
    <div className="py-10">
      <h2 className="text-2xl font-bold text-navybrand">Services</h2>
      <div className="grid md:grid-cols-2 gap-6 mt-4">
        <div className="card p-6">
          <div className="font-semibold">Medicine Delivery</div>
          <p className="text-sm text-gray-700 mt-2">Same-day delivery within our service radius.</p>
        </div>
        <div className="card p-6">
          <div className="font-semibold">Refill Reminders</div>
          <p className="text-sm text-gray-700 mt-2">Get notified when it’s time to refill your meds.</p>
        </div>
        <div className="card p-6">
          <div className="font-semibold">BP/Glucose Check</div>
          <p className="text-sm text-gray-700 mt-2">Walk-in checks with trained staff.</p>
        </div>
        <div className="card p-6">
          <div className="font-semibold">Counseling & Vaccination</div>
          <p className="text-sm text-gray-700 mt-2">Pharmacist counseling and vaccinations (if available).</p>
        </div>
        <div className="card p-6">
          <div className="font-semibold">Device Demos & Returns (non‑Rx)</div>
          <p className="text-sm text-gray-700 mt-2">Try devices and hassle-free returns on eligible items.</p>
        </div>
      </div>
    </div>
  );
}
