import type { Metadata } from "next";
import "./globals.css";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import StickyBar from "@/components/StickyBar";
import CookieBanner from "@/components/CookieBanner";
import { site } from "@/site.config";
import Script from "next/script";

export const metadata: Metadata = {
  title: `${site.brand} | Your Trusted Neighborhood Pharmacy in ${site.city}`,
  description: `Licensed pharmacists, genuine medicines, and same-day delivery in ${site.city}.`,
  openGraph: {
    title: `${site.brand} | Pharmacy in ${site.city}`,
    description: "Order medicines, upload prescriptions, and get fast local delivery.",
    url: "https://example.com",
    siteName: site.brand,
    images: ["/images/hero.jpg"],
    locale: "en_IN",
    type: "website",
  },
  alternates: {
    canonical: "/"
  }
};

export default function RootLayout({ children }: { children: React.ReactNode; }) {
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Pharmacy",
    "name": site.brand,
    "address": {
      "@type": "PostalAddress",
      "streetAddress": site.address,
      "addressLocality": site.city,
      "addressCountry": site.country
    },
    "telephone": site.phone,
    "openingHours": site.hours,
    "areaServed": `${site.city} (${site.serviceRadiusKm} km)`
  };
  return (
    <html lang="en">
      <body>
        <Navbar />
        <main className="container">{children}</main>
        <Footer />
        <StickyBar />
        <CookieBanner />
        <Script type="application/ld+json" id="jsonld" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      </body>
    </html>
  );
}
