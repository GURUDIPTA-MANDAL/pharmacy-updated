import Link from "next/link";
import { site } from "@/site.config";
import Testimonials from "@/components/Testimonials";

export default function Home() {
  return (
    <>
      <section className="py-12 grid md:grid-cols-2 gap-8 items-center">
        <div>
          <h1 className="text-4xl md:text-5xl font-extrabold text-navybrand">
            Medicines delivered fast. Care that’s even faster.
          </h1>
          <p className="mt-4 text-gray-700">
            Licensed pharmacists, genuine medicines, and same-day delivery in {site.city}.
          </p>
          <div className="mt-6 flex gap-3">
            <Link href="/shop" className="btn btn-primary">Order Medicines</Link>
            <Link href="/upload" className="btn btn-secondary">Upload Prescription</Link>
          </div>
          <div className="mt-6 grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
            <div className="badge">24/7 support</div>
            <div className="badge">Licensed pharmacists</div>
            <div className="badge">Fast delivery {site.serviceRadiusKm} km</div>
            <div className="badge">Easy returns (non‑Rx)</div>
          </div>
        </div>
        <div>
          <img src="/images/hero.jpg" alt="Pharmacy care" className="w-full h-72 object-cover"/>
        </div>
      </section>

      <section className="py-10">
        <div className="text-2xl font-bold text-navybrand">Shop by category</div>
        <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-4">
          <Link href="/shop?cat=OTC" className="card p-6">OTC</Link>
          <Link href="/shop?cat=Personal%20Care" className="card p-6">Personal Care</Link>
          <Link href="/shop?cat=Wellness" className="card p-6">Wellness</Link>
          <Link href="/shop?cat=Devices" className="card p-6">Devices</Link>
        </div>
      </section>

      <section className="py-10">
        <Testimonials />
      </section>
    </>
  );
}
