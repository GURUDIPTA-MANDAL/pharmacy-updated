'use client';
import { useMemo, useState } from "react";
import { products, categories, type Product } from "@/lib/data";
import ProductCard from "@/components/ProductCard";
import { useSearchParams } from "next/navigation";

export default function ShopPage(){
  const params = useSearchParams();
  const initialCat = params.get('cat') ?? 'All';
  const [query, setQuery] = useState('');
  const [cat, setCat] = useState<string>(initialCat);

  const names = useMemo(()=> products.map(p => p.name), []);

  const filtered = products.filter(p => {
    const okCat = (cat === 'All') || (p.category === cat || (cat==='Personal Care' && p.category==='OTC'));
    const okQuery = !query || p.name.toLowerCase().includes(query.toLowerCase());
    return okCat && okQuery;
  });

  return (
    <div className="py-10">
      <h2 className="text-2xl font-bold text-navybrand">Shop / Medicines</h2>
      <div className="mt-4 flex flex-wrap gap-3 items-center">
        <input list="names" value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search products..." className="min-w-[260px]"/>
        <datalist id="names">
          {names.map(n => <option key={n} value={n} />)}
        </datalist>
        <select value={cat} onChange={e=>setCat(e.target.value)}>
          <option>All</option>
          {categories.map(c => <option key={c}>{c}</option>)}
          <option>Personal Care</option>
        </select>
      </div>

      <div className="mt-6 grid md:grid-cols-3 gap-6">
        {filtered.map((p: Product) => <ProductCard key={p.id} product={p} />)}
      </div>
      <div className="mt-6 text-xs text-gray-600">
        * For prescription items, you must upload a valid prescription before purchase.
      </div>
    </div>
  );
}
