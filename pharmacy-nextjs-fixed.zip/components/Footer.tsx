import { site } from '@/site.config';

export default function Footer() {
  return (
    <footer className="mt-16 border-t border-gray-100">
      <div className="container py-10 grid md:grid-cols-4 gap-8 text-sm">
        <div>
          <div className="text-lg font-semibold text-navybrand">{site.brand}</div>
          <p className="mt-2 text-gray-600">Prescription-only medicines are dispensed only against a valid prescription from a registered medical practitioner.</p>
          <p className="mt-2 text-gray-500">Content is for informational purposes only and does not replace professional medical advice.</p>
        </div>
        <div>
          <div className="font-semibold">Contact</div>
          <p className="mt-2">{site.address}</p>
          <p>{site.city}, {site.country}</p>
          <p>Phone: {site.phone}</p>
          <p>WhatsApp: {site.whatsapp}</p>
          <p>Email: {site.email}</p>
          <p className="mt-2">{site.hours}</p>
        </div>
        <div>
          <div className="font-semibold">Quick Links</div>
          <ul className="mt-2 space-y-2">
            <li><a href="/shop">Shop</a></li>
            <li><a href="/upload">Upload Prescription</a></li>
            <li><a href="/services">Services</a></li>
            <li><a href="/about">About</a></li>
            <li><a href="/blog">Blog</a></li>
            <li><a href="/legal">Legal</a></li>
          </ul>
        </div>
        <div>
          <div className="font-semibold">Social</div>
          <ul className="mt-2 space-y-2">
            <li><a href={site.social.facebook}>Facebook</a></li>
            <li><a href={site.social.instagram}>Instagram</a></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-gray-100">
        <div className="container py-6 text-xs text-gray-500">
          © {new Date().getFullYear()} {site.brand}. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
