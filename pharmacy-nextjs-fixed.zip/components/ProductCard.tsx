'use client';
import { Product } from '@/lib/data';
import { useState } from 'react';

export default function ProductCard({ product }: { product: Product }){
  const [qty, setQty] = useState(1);
  return (
    <div className="card p-4 flex flex-col">
      <img src={product.image} alt={product.name} className="h-40 w-full object-cover"/>
      <div className="mt-3 font-semibold">{product.name}</div>
      <div className="text-sm text-gray-600">{product.benefits.join(' • ')}</div>
      <div className="mt-2 text-navybrand font-bold">₹{product.price}</div>
      <div className="mt-1 text-xs text-gray-500">{product.stock} in stock</div>
      {product.rxRequired && (
        <div className="mt-2 text-xs text-red-600">Requires Prescription — <a href="/upload">Upload to Purchase</a></div>
      )}
      <div className="mt-3 flex items-center gap-2">
        <input type="number" min={1} value={qty} onChange={e=>setQty(parseInt(e.target.value||'1'))} className="w-16"/>
        <button className="btn btn-primary">Add to Cart</button>
      </div>
    </div>
  );
}
