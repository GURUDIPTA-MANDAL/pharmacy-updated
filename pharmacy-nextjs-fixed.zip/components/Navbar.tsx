'use client';
import Link from 'next/link';
import { site } from '@/site.config';
import { useState } from 'react';

export default function Navbar() {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-50 bg-white/90 backdrop-blur border-b border-gray-100">
      <div className="container flex items-center justify-between h-16">
        <Link href="/" className="text-xl font-bold text-navybrand">{site.brand}</Link>
        <nav className="hidden md:flex gap-6 text-sm">
          <Link href="/shop">Shop</Link>
          <Link href="/upload">Upload Prescription</Link>
          <Link href="/services">Services</Link>
          <Link href="/about">About</Link>
          <Link href="/blog">Blog</Link>
          <Link href="/contact">Contact</Link>
          <Link href="/legal">Legal</Link>
        </nav>
        <div className="md:hidden">
          <button className="btn btn-primary" onClick={()=>setOpen(!open)}>Menu</button>
        </div>
      </div>
      {open && (
        <div className="md:hidden border-t border-gray-100">
          <div className="container py-3 flex flex-col gap-3">
            <Link href="/shop" onClick={()=>setOpen(false)}>Shop</Link>
            <Link href="/upload" onClick={()=>setOpen(false)}>Upload Prescription</Link>
            <Link href="/services" onClick={()=>setOpen(false)}>Services</Link>
            <Link href="/about" onClick={()=>setOpen(false)}>About</Link>
            <Link href="/blog" onClick={()=>setOpen(false)}>Blog</Link>
            <Link href="/contact" onClick={()=>setOpen(false)}>Contact</Link>
            <Link href="/legal" onClick={()=>setOpen(false)}>Legal</Link>
          </div>
        </div>
      )}
    </header>
  );
}
