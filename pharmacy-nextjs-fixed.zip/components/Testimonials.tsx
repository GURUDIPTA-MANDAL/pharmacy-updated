'use client';
import { testimonials, brandLogos } from '@/lib/data';
import { useEffect, useState } from 'react';

export default function Testimonials(){
  const [index, setIndex] = useState(0);
  useEffect(()=>{
    const t = setInterval(()=> setIndex(i => (i+1) % testimonials.length), 3000);
    return ()=> clearInterval(t);
  },[]);
  const t = testimonials[index];
  return (
    <div className="card p-6">
      <div className="text-center">
        <div className="text-lg font-semibold">What our customers say</div>
        <p className="mt-2 text-gray-600 italic">“{t.text}”</p>
        <div className="mt-1 text-sm text-gray-700">— {t.name}</div>
      </div>
      <div className="mt-6 grid grid-cols-3 md:grid-cols-6 gap-4 items-center opacity-70">
        {brandLogos.map((src,i)=> <img key={i} src={src} alt="brand logo" className="h-8 object-contain"/>)}
      </div>
    </div>
  );
}
