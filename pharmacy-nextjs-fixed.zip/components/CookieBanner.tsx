'use client';
import { useEffect, useState } from 'react';

export default function CookieBanner(){
  const [show, setShow] = useState(false);
  useEffect(()=>{
    const ok = localStorage.getItem('cookie-ok');
    if(!ok) setShow(true);
  },[]);
  if(!show) return null;
  return (
    <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-50 card p-4 max-w-xl">
      <div className="flex items-start gap-4">
        <div className="text-sm">
          We use cookies to improve your experience. By using this site, you agree to our Privacy Policy.
        </div>
        <button className="btn btn-primary" onClick={()=>{localStorage.setItem('cookie-ok','1'); setShow(false);}}>OK</button>
      </div>
    </div>
  );
}
