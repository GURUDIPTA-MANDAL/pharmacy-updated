'use client';
import { site } from '@/site.config';
export default function StickyBar(){
  return (
    <div className="fixed md:hidden bottom-0 left-0 right-0 bg-white/95 backdrop-blur border-t border-gray-200 z-50">
      <div className="container py-2 grid grid-cols-4 gap-2">
        <a className="btn btn-secondary text-center text-sm" href={`tel:${site.phone}`}>Call</a>
        <a className="btn btn-primary text-center text-sm" href={`https://wa.me/${site.whatsapp.replace(/\D/g,'')}`} target="_blank">WhatsApp</a>
        <a className="btn text-sm bg-gray-900 text-white text-center" href="/upload">Upload</a>
        <a className="btn text-sm bg-gray-800 text-white text-center" href="/shop">Cart</a>
      </div>
    </div>
  );
}
