export type Product = {
  id: string;
  name: string;
  category: "OTC" | "Prescription" | "Wellness" | "Devices";
  image: string;
  benefits: string[];
  price: number;
  stock: number;
  rxRequired?: boolean;
};

export const categories = ["OTC", "Prescription", "Wellness", "Devices"] as const;

export const products: Product[] = [
  {
    id: "paracetamol-650",
    name: "Paracetamol 650mg (OTC)",
    category: "OTC",
    image: "/images/paracetamol.jpg",
    benefits: ["Fever reduction", "Relieves mild pain"],
    price: 45,
    stock: 120
  },
  {
    id: "bp-monitor",
    name: "Digital BP Monitor",
    category: "Devices",
    image: "/images/bp.jpg",
    benefits: ["Accurate readings", "Easy to use"],
    price: 1899,
    stock: 22
  },
  {
    id: "rx-amoxicillin",
    name: "Amoxicillin 500mg",
    category: "Prescription",
    image: "/images/rx.jpg",
    benefits: ["Bacterial infections"],
    price: 120,
    stock: 15,
    rxRequired: true
  },
  {
    id: "vitamin-c",
    name: "Vitamin C 1000mg",
    category: "Wellness",
    image: "/images/vitc.jpg",
    benefits: ["Immunity support", "Antioxidant"],
    price: 299,
    stock: 56
  }
];

export const testimonials = [
  { name: "Anita", text: "Fast delivery and very polite staff." },
  { name: "Rohit", text: "Loved the refill reminders, super handy!" },
  { name: "Fatima", text: "Genuine medicines and clear advice." }
];

export const brandLogos = ["/images/brand1.png","/images/brand2.png","/images/brand3.png"];
