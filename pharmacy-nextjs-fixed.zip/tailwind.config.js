/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}"
  ],
  theme: {
    extend: {
      colors: {
        tealbrand: "#17A2A6",
        navybrand: "#0B2545"
      },
      borderRadius: {
        '2xl': '1rem'
      },
      boxShadow: {
        'soft': '0 6px 24px rgba(0,0,0,0.08)'
      }
    },
  },
  plugins: [],
}
