export const site = {
  brand: "HealthFirst Pharmacy",
  city: "Kolkata",
  country: "India",
  serviceRadiusKm: 8,
  whatsapp: "+91 98765 43210",
  email: "care@healthfirstpharmacy.in",
  phone: "+91 70000 00000",
  address: "12A, Park Street, Kolkata, West Bengal 700016",
  hours: "Mon–Sun: 8:00 AM – 10:00 PM",
  pharmacist: {
    name: "Rahul Sen, RPh",
    licenseNo: "DL-19-XXXXX",
    years: 10
  },
  social: {
    facebook: "#",
    instagram: "#"
  }
};
